package com.charlie.gridview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class eqpdetails extends AppCompatActivity {

    String []list=MainActivity.last.split("@@@@");
    String []detials1=list[0].split("@@");
    String []detials2=list[1].split("@@");
    ImageView i1,i2;
    TextView n1,n2,p1,p2,d1,d2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eqpdetails);
        i1=findViewById(R.id.image1);
        i2=findViewById(R.id.image2);
        n1=findViewById(R.id.name1);
        n2=findViewById(R.id.name2);

        p1=findViewById(R.id.price1);
        p2=findViewById(R.id.price2);
        d1=findViewById(R.id.description1);
        d2=findViewById(R.id.description2);
        i1.setImageResource(MainActivity.ei);
        i2.setImageResource(MainActivity.ei);
        n1.setText(detials1[0]);
        n2.setText(detials2[0]);
        p1.setText(detials1[1]);
        p2.setText(detials2[1]);
        d1.setText(detials1[2]);
        d2.setText(detials2[2]);

    }

}
