package com.charlie.gridview;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    GridView gridview;
    public static int ei=0;
    public static List<String> diseasenames = new ArrayList<>();
    public static List<Integer> diseaseimages = new ArrayList<>();
    public static List<String> eqpnames = new ArrayList<>();
    public static List<Integer> eqpimages = new ArrayList<>();
    public static String last="";
    public static String BMD_machine="Omran Karada HBF-375 Body fat analyzer@@Rs.11800@@A bone density test determines if you have osteoporosis — a disorder characterized by bones that are more fragile and more likely to break.@@@@India Health Machine QRM health analyzer full body check@@Rs.6850@@BMD machine's are widely used in medical camps for measuring bone mineral density. It is offered to clients in different models and specifications to outfit to individual needs. Japanese BMD Machine has incorporated with latest technology. It is considered to be world''s best digital machine for use in hospitals and also for organized BMD Camps.";
    public static String Knee_cap="JSB backpain heating belt@@Rs.1899@@Stryker's Sports Medicine business delivers a wide range of innovative sports medicine implants, instrumentation, resection and biologic solutions. Our solutions focus on minimally invasive and open approaches to the shoulder, knee hip and small joints. @@@@Lifelong LLM27 Electric Handheld Full Body Massager@@Rs.974@@The knee cap is located on the anterior side of the knee. It is embedded in the tendon of the thigh muscles. The knee cap serves the transmission of force while extending the knee and protects the internal regions of the joint. The knee joint is surrounded by a joint capsule.";
    public static String Neuro1="Grip Strengthener@@Rs.259@@Neuroradiology in which minimally invasive therapy can be effected by advancing various devices within a blood vessel to a point of a previously identified lesion–eg, an intracranial aneurysm. @@@@FEGSY Resistance Tube @@Rs.799@@Human Brain Diseases List with Diagnostic Symptoms Brain Cancer/Tumor. Talking about the brain diseases list, cancer and tumor are the terms that are used alternatively as... Alzheimer's Disease. ";
    public static String Neuro2="WOW Skin Science Vitamin C Serum@@Rs.569@@Neurostimulation is the purposeful modulation of the nervous system's activity using invasive or non-invasive means. Neurostimulation usually refers to the electromagnetic approaches to neuromodulation@@@@Cosmoderm Derma Roller 540 Titanium Needle@@Rs.499@@Brain injuries. Brain injuries are often caused by blunt trauma. Trauma can damage brain tissue, neurons, and nerves. Brain tumors";
    public static String thermo="Dr Trust (Usa) Waterproof Flexible Tip Digital Thermometer @@Rs.299@@A fever is a temporary increase in your body temperature, often due to an illness. Having a fever is a sign that something out of the ordinary is going on in your body. For an adult, a fever may be uncomfortable, but usually isn't a cause for concern unless it reaches 103 F (39.4 C) or higher@@@@k-Life KLT-100 Digital Thermometer with storage case@@Rs.199@@Human Body Temperature. Human body temperature is measured in order to reflect relative health.";
    public static String dengue="Medrop Dengue NS1 Antigen Combo-Pack of 10@@Rs.1500@@    Those who become infected with the virus a second time are at a significantly greater risk of developing severe disease.@@@@Krishna's Herbal & Ayurveda Papaya Leaf Juice Remedy for Dengue Fever - 500 ml@@Rs.180@@Concurrent evaluation for the NS1 antigen alongside testing for IgM- and IgG-class antibodies to DV (DENGM) provides optimal diagnostic potential for both early and late dengue disease.";
    public static String asthma1="Medtech Products Handyvap-Steam Inhaler@@Rs.445@@ Asthma can be minor or it can interfere with daily activities. In some cases, it may lead to a life-threatening attack.@@@@Rockshop Mouthpiece Dose Inhler@@Rs.649@@Generally used for infants or small children, this type uses a standard metered dose inhaler with a spacer. The face mask, which attaches to the spacer, fits over the nose and mouth to make sure the right dose of medication reaches the lungs.";
    public static String asthma2="Compresser Complete Kit Nebulizer@@Rs.999@@Asthma is a common long-term inflammatory disease of the airways of the lungs. It is characterized by variable and recurring symptoms, reversible airflow obstruction, and easily triggered bronchospasms@@@@Meditive Handy Respiratory Nebulizer@@Rs.1199@@This device turns asthma medication into a fine mist breathed in through a mouthpiece or mask worn over the nose and mouth. A nebulizer is generally used for people who can't use an inhaler, such as infants, young children, people who are very ill or people who need large doses of medication.";
    public static String canes="bmd@@35@@The muscular system is responsible for the movement of the human body. Attached to the bones of the skeletal system are about 700 named muscles that make up roughly half of a person’s body weight@@@@bmd2@@450@@Hook Massage Stick for Back, Foot, Neck Muscle, Shoulder, Lower Body, Hand, Leg - Self Trigger Point Acupressure Deep Tissue Therapy - Myofascial Release Tool";
    public static String crutches="bmd@@350@@Muscle, contractile tissue found in animals, the function of which is to produce motion. striated muscle; human biceps muscle The structure of striated muscle.@@@@bmd2@@450@@If you fall victim to an unexpected accident and got injured in the lower body area involving heaps and legs or go under surgery, you must have to use the crutches to move during the recovery period from the injury.";
    public static String neutrogenal="Neutrogena Hydroboost Water Gel 50gm@@Rs.950@@The acenes or polyacenes are a class of organic compounds and polycyclic aromatic hydrocarbons made up of linearly fused benzene rings.@@@@Neutrogena Hydroboost@@Rs.699@@The unique water gel formula absorbs quickly like a gel, but has the long-lasting, intense moisturizing power of a cream. This gel moisturizer is formulated with hyaluronic acid, which is naturally found in the skin.";
    public static String skinceuticals="WOW Skin Science Vitamin C Serum@@Rs.569@@Use Neutrogena Hydro Boost Water Gel to instantly quench dry skin and boost's skin's hydration level. This oil-free formula quenches dry skin to keep it looking smooth, supple, and hydrated day after day.@@@@Cosmoderm Derma Roller 540 Titanium Needle@@499@@Phloretin CF features a patented synergistic combination of 2% phloretin, 10% pure vitamin C (l-ascorbic acid), and 0.5% ferulic acid for enhanced protection against atmospheric skin aging – environmental damage and premature signs of aging caused by free radicals from UVA/UVB, infrared radiation (IRA), and ozone pollution (O3).";

    public static String armhand="FEGSY Resistance Tube @@Rs.1340@@If you or someone you're with may be having a stroke, pay particular attention to the time the symptoms began. Some treatment options are most effective when given soon after a stroke begins.@@@@Lifelong LLF63 Fit Pro @@Rs.2047@@However, in common, literary, and historical usage, arm refers to the entire upper limb from shoulder to wrist. This article uses the former definition; see upper limb for the wider definition. In primates the arm is adapted for precise positioning of the hand and thus assist in the hand's manipulative tasks. ";
    public static String armpeddler="Inditradition Mini Pedal @@Rs.1999@@Trouble speaking and understanding what others are saying. You may experience confusion, slur your words or have difficulty understanding speech.@@@@ Jaspo Derby Dolls Intact@@Rs.1349@@Arm Pedaling A great piece of stroke rehab equipment for arm mobility is an arm peddler. Because the movement is bilateral, you can use your non-affected arm to assist your affected arm. ";
    public static String endo=" Romsons Endotracheal Tube @@Rs.174@@A flexible plastic tube that is put in the mouth and then down into the trachea (airway). A physician inserts an endotracheal tube under direct vision, with the help of a laryngoscope, in a procedure called endotracheal intubation. @@@@ONTEX Adult Endotracheal @@Rs.600@@The tongue may traumatized by mechanical, thermal, electrical or chemical means. A common scenario is where the tongue is bitten accidentally whilst a local anesthetic inferior alveolar nerve block is wearing off.";
    public static String flatus=" Medvision Bougie Vented@@Rs.740@@It is reusable rubber tube used for the removal of flatus .It is also used for the treatment of sigmoid volvulus and intussusception. It is used also for barium enema.@@@@Romsons Endotracheal Tube@@Rs.180@@Poor diet can cause malnutrition and nutritional deficiencies. Deficiency of iron, B vitamins and folic acid are common causes for atrophic glossitis.";
    public static HashMap<String,String>obj=new HashMap<String,String>();







    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        gridview = findViewById(R.id.gridview);
diseasenames.add("Bone");
        diseasenames.add("Brain");
        diseasenames.add("Fever");
        diseasenames.add("Lungs");
        diseasenames.add("Muscle");
        diseasenames.add("Skin");
        diseasenames.add("Stroke");
        diseasenames.add("Tongue");
       diseaseimages.add(R.drawable.bone);
        diseaseimages.add(R.drawable.brain);
        diseaseimages.add(R.drawable.fever);
        diseaseimages.add(R.drawable.lungs);
        diseaseimages.add(R.drawable.muscles);
        diseaseimages.add(R.drawable.skin);
        diseaseimages.add(R.drawable.stroke);
        diseaseimages.add(R.drawable.tongue);
        obj.put("BMD machine",BMD_machine);
        obj.put("Knee cap",Knee_cap);
        obj.put("Neurointerventional Device",Neuro1);
        obj.put("Neuro Stimulation",Neuro2);
        obj.put("Thermometer",thermo);
        obj.put("Dengue NSI Antigen",dengue);
        obj.put("Asthma Inhaler",asthma1);
        obj.put("Asthma Nebulizer",asthma2);
        obj.put("Canes",canes);
        obj.put("Crutches",crutches);
        obj.put("Neutrogenel Hydro Boost",neutrogenal);
        obj.put("Skinceuticals",skinceuticals);
        obj.put("Arm Hand",armhand);
        obj.put("Arm Peddlers",armpeddler);
        obj.put("Endotracheal tubes",endo);
        obj.put("Flatus Tube",flatus);






        CustomAdapter customAdaptor = new CustomAdapter();

        gridview.setAdapter(customAdaptor);
        gridview.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i,long l)
            {
                String t=diseasenames.get(i);


                if(t=="Bone")
                {
                    eqpnames.clear();
                    eqpimages.clear();
                    eqpnames.add("BMD machine");
                    eqpimages.add(R.drawable.bmdmachine
                    );
                    eqpnames.add("Knee cap");
                    eqpimages.add(R.drawable.kneecap);
                }
                if(t=="Brain") {eqpnames.clear();
                    eqpimages.clear();
                    eqpnames.add("Neurointerventional Device");
                    eqpimages.add(R.drawable.neurointerventional);
                    eqpnames.add("Neuro Stimulation");
                    eqpimages.add(R.drawable.neurostimulation);

                }
                if(t=="Fever") {
                    eqpnames.clear();
                    eqpimages.clear();
                    eqpnames.add("Thermometer");
                    eqpimages.add(R.drawable.thermometer);
                    eqpnames.add("Dengue NSI Antigen");
                    eqpimages.add(R.drawable.denguens1antigen);
                }
                if(t=="Lungs") {
                    eqpnames.clear();
                    eqpimages.clear();
                    eqpnames.add("Asthma Inhaler");
                    eqpimages.add(R.drawable.asthmainhaler);
                    eqpnames.add("Asthma Nebulizer");
                    eqpimages.add(R.drawable.asthmanebulizer);
                }
                if(t=="Muscle") {
                    eqpnames.clear();
                    eqpimages.clear();
                    eqpnames.add("Canes");
                    eqpimages.add(R.drawable.canes);
                    eqpnames.add("Crutches");
                    eqpimages.add(R.drawable.crutches);
                }
                if(t=="Skin") {
                    eqpnames.clear();
                    eqpimages.clear();
                    eqpnames.add("Neutrogenel Hydro Boost");
                    eqpimages.add(R.drawable.neutogenal);
                    eqpnames.add("Skinceuticals");
                    eqpimages.add(R.drawable.skinceuticals);
                }
                if(t=="Stroke") {
                    eqpnames.clear();
                    eqpimages.clear();
                    eqpnames.add("Arm Hand");
                    eqpimages.add(R.drawable.armandhand);
                    eqpnames.add("Arm Peddlers");
                    eqpimages.add(R.drawable.armpeddlers);
                }
                if(t=="Tongue") {
                    eqpnames.clear();
                    eqpimages.clear();
                    eqpnames.add("Endotracheal Tubes");
                    eqpimages.add(R.drawable.endotracheal);
                    eqpnames.add("Flatus Tubes");
                    eqpimages.add(R.drawable.flatustube);
                }
startActivity(new Intent(MainActivity.this,activity_grid_item.class));

            }
        });
    }

    private class CustomAdapter extends BaseAdapter {
        @Override
        public int getCount()
        {
            return diseaseimages.size();
        }

        @Override
        public Object getItem(int i)
        {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @SuppressLint("ViewHolder")
        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {

            view = getLayoutInflater().inflate(R.layout.row_data, null);
            TextView name = view.findViewById(R.id.disease);
          ImageView image = view.findViewById(R.id.images);
            name.setText(diseasenames.get(i));
            image.setImageResource(diseaseimages.get(i));

            return view;
        }
    }
}


