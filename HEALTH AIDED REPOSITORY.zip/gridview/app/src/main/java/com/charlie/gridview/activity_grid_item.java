package com.charlie.gridview;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

public class activity_grid_item extends AppCompatActivity {
    GridView gridview;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid_item);
        gridview = findViewById(R.id.gridview1);

        CustomAdapter customAdaptor = new CustomAdapter();

        gridview.setAdapter(customAdaptor);
        gridview.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l)
            {

String c=MainActivity.eqpnames.get(i);
MainActivity.ei=MainActivity.eqpimages.get(i);
MainActivity.last=MainActivity.obj.get(c);

                startActivity(new Intent(activity_grid_item.this,eqpdetails.class));




            }
        });
    }
    private class CustomAdapter extends BaseAdapter {
        @Override
        public int getCount()
        {
            return MainActivity.eqpimages.size();
        }

        @Override
        public Object getItem(int i)
        {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @SuppressLint("ViewHolder")
        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {

            view = getLayoutInflater().inflate(R.layout.row_data, null);
            TextView name = view.findViewById(R.id.disease);
            ImageView image = view.findViewById(R.id.images);
            name.setText(MainActivity.eqpnames.get(i));
            image.setImageResource(MainActivity.eqpimages.get(i));
            return view;
        }
    }
}




